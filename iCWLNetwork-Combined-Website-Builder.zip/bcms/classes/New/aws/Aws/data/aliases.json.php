<?php
// This file was auto-generated from sdk-root/src/data/aliases.json
return [ 'operations' => [ 'ApiGatewayV2' => [ '2018-11-29' => [ 'GetApi' => 'GetApiResource', ], ], 'CloudHSM' => [ '2014-05-30' => [ 'GetConfig' => 'GetConfigFiles', ], ], 'GroundStation' => [ '2019-05-23' => [ 'GetConfig' => 'GetMissionProfileConfig', ], ], 'Pinpoint' => [ '2016-12-01' => [ 'GetEndpoint' => 'GetUserEndpoint', 'UpdateEndpoint' => 'UpdateUserEndpoint', 'UpdateEndpointsBatch' => 'UpdateUserEndpointsBatch', ], ], ],];
