<?php
// This file was auto-generated from sdk-root/src/data/backupstorage/2018-04-10/paginators-1.json
return [ 'pagination' => [ 'ListChunks' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListObjects' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
