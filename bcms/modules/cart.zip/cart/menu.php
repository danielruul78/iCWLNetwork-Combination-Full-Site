<span class="leftside">
	<script type="text/javascript" src="../../jscript/p7tmscripts.js"></script>
	<div id="p7TMctrl" align="center">
		<a href="#" onClick="P7_TMall(0);return false">Expand All</a> | <a href="#" onClick="P7_TMall(1);return false">Collapse All</a>
	</div>
	<div  id="p7TMnav">
		<div><a href="#" onClick="P7_TMenu(this);return false" style='color: #666666' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#666666'"><img src='../../images/arrow2.gif' border='0'>ADMINISTRATORS</a>
			<div>
				<a href='../administrators/index.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Add</a>
			</div>
			<div>
				<a href='../administrators/modify.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Modify</a>
			</div>
			<div>
				<a href='../administrators/password.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Change Password</a>
			</div>
		</div>
		<div><a href="#" onClick="P7_TMenu(this);return false" style='color: #666666' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#666666'"><img src='../../images/arrow2.gif' border='0'>PRODUCTS</a>
			<div>
				<a href='../products/index.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Add</a>
			</div>
			<div>
				<a href='../products/modify.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Modify</a>
			</div>
			
		</div>
		<div><a href="#" onClick="P7_TMenu(this);return false" style='color: #666666' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#666666'"><img src='../../images/arrow2.gif' border='0'>ORDERS</a>
			<div>
				<a href='../orders/modify.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>View</a>
			</div>
			
		</div>
		<div><a href="#" onClick="P7_TMenu(this);return false" style='color: #666666' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#666666'"><img src='../../images/arrow2.gif' border='0'>SETUP</a>
			<div>
				<a href='../setup/recipient-emails.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Admin Emails</a>
			</div>
			<div>
				<a href='../setup/preferences.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Preferences</a>
			</div>
		</div>
		<div><a href="#" onClick="P7_TMenu(this);return false" style='color: #666666' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#666666'"><img src='../../images/arrow2.gif' border='0'>LINKS</a>
			<div>
				<a href='../links/index.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Add Category</a>
			</div>
			<div>
				<a href='../links/modify.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Modify Categories</a>
			</div>
			<div>
				<a href='../links/index-links.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Add Link</a>
			</div>
			<div>
				<a href='../links/modify-links.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Modify Links</a>
			</div>
		</div>
		<div><a href="#" onClick="P7_TMenu(this);return false" style='color: #666666' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#666666'"><img src='../../images/arrow2.gif' border='0'>TESTIMONIALS</a>
			<div>
				<a href='../testimonials/index.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Add</a>
			</div>
			<div>
				<a href='../testimonials/modify.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Modify</a>
			</div>
			
		</div>
		<div><a href="#" onClick="P7_TMenu(this);return false" style='color: #666666' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#666666'"><img src='../../images/arrow2.gif' border='0'>CONTENT PAGES</a>
			<div>
				<a href='../content/add-content.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Add</a>
			</div>
			<div>
				<a href='../content/view-content.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Modify</a>
			</div>
			
		</div>
		<div><a href="#" onClick="P7_TMenu(this);return false" style='color: #666666' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#666666'"><img src='../../images/arrow2.gif' border='0'>PHOTOGALLERY</a>
			<div>
				<a href='../photogallery/index-categories.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Add Category</a>
			</div>
			<div>
				<a href='../photogallery/modify-categories.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Modify Categories</a>
			</div>
			<div>
				<a href='../photogallery/index.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Add</a>
			</div>
			<div>
				<a href='../photogallery/modify.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>Modify</a>
			</div>
			
		</div>
		<div>
		<a href='../logged-in/index.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>HOME</a></div>
		<div>
			<a href='../../logout.php' style='color: #363E57' onMouseOver="this.style.color='#6979A3'" onMouseOut="this.style.color='#363E57'"><img src='../../images/arrow1.gif' border='0'>LOGOUT</a>
		</div>
	</div>	      
</span>

