<?php
  $connect["database.php"] = array('hostname'=>'db.toho9000.com.au','usernamedb'=>'toho9000','passworddb'=>'9000toho','dbName'=>'toho9000');
  $connect["databaseau.php"] = array('hostname'=>'db.toho9000.com.au','usernamedb'=>'toho9000','passworddb'=>'9000toho','dbName'=>'toho9000');
  //$connect["database.php"] = array('hostname'=>'localhost','usernamedb'=>'toho9000','passworddb'=>'9000toho','dbName'=>'toho9000');
?>